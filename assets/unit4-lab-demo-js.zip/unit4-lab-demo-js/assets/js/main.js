function changeToDark() {
	document.getElementsByTagName("body")[0].style.backgroundColor = "black";
	document.getElementsByTagName("body")[0].style.color = "white";
}

document.getElementById("darkBtn").addEventListener("click", changeToDark);