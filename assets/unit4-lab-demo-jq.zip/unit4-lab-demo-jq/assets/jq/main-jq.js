$( document ).ready(function() {
 
    $("#darkBtn").click(function( event ) {
        $("body").css({
            backgroundColor: "black",
            color: "white"
        });
    });
 
});