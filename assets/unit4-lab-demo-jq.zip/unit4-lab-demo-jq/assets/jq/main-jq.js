$( document ).ready(function() {
 
    $("#darkBtn").click(function( event ) {
        $("body").css("background-color", "black");
        $("body").css("color", "white");
    });
 
});